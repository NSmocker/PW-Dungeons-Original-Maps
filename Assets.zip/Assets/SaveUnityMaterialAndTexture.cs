using UnityEngine;
using UnityEditor;
using System.IO;

public class SaveAllMaterialsAndTextures : MonoBehaviour
{
    // Скрипт автоматично отримує компонент Renderer
    private Renderer objectRenderer;

    private void Awake()
    {
        // Автоматично отримуємо Renderer, якщо він не заданий вручну
        
    }

    public void SaveAllMaterialsAndTexturesProcces()
    {   objectRenderer = GetComponent<Renderer>();
        if (objectRenderer == null)
        {
            Debug.LogError("Renderer is not assigned or found on the object!");
            return;
        }

        // Шляхи для збереження
        string sceneName = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name;
        string objectName = gameObject.name;
        string savePath = $"Assets/{sceneName}/{objectName}/";

        // Створити директорію, якщо її немає
        if (!Directory.Exists(savePath))
        {
            Directory.CreateDirectory(savePath);
        }

        // Отримуємо всі матеріали з Renderer
        Material[] materials = objectRenderer.sharedMaterials;

        for (int i = 0; i < materials.Length; i++)
        {
            Material material = materials[i];
            string materialName = $"{objectName}_{i}_id";
            string materialPath = $"{savePath}{materialName}.mat";

            // Збереження текстури матеріалу
            Texture2D albedoTexture = material.mainTexture as Texture2D;
            if (albedoTexture != null)
            {
                string texturePath = $"{savePath}{materialName}_albedo.png";
                SaveTextureAsPNG(albedoTexture, texturePath);

                // Оновити посилання на текстуру
                AssetDatabase.ImportAsset(texturePath);
                albedoTexture = AssetDatabase.LoadAssetAtPath<Texture2D>(texturePath);

                // Оновлюємо матеріал із новою текстурою
                material.mainTexture = albedoTexture;
            }
            else
            {
                Debug.LogWarning($"Albedo texture not found for material: {material.name}");
            }

            // Створення і збереження нового Unity-матеріалу
            SaveUnityMaterial(materialPath, material);
        }
    }

    private void SaveTextureAsPNG(Texture2D texture, string path)
    {
        byte[] bytes = texture.EncodeToPNG();
        File.WriteAllBytes(path, bytes);
        Debug.Log("Texture saved to: " + path);
    }

    private void SaveUnityMaterial(string path, Material material)
    {
        Material newMaterial = new Material(Shader.Find("HDRP/Lit"));

        // Копіюємо всі властивості з оригінального матеріалу
        newMaterial.CopyPropertiesFromMaterial(material);

        AssetDatabase.CreateAsset(newMaterial, path);
        AssetDatabase.SaveAssets();
        Debug.Log($"Material saved to: {path}");
    }
}
