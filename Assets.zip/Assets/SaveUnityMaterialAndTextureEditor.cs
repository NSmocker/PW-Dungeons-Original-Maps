using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(SaveAllMaterialsAndTextures))]
public class SaveAllMaterialsAndTexturesEditor : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector(); // Відображення стандартного інспектора

        SaveAllMaterialsAndTextures script = (SaveAllMaterialsAndTextures)target;

        if (GUILayout.Button("Save All Materials and Textures"))
        {
            script.SaveAllMaterialsAndTexturesProcces(); // Виклик методу збереження
            Debug.Log("Saved all materials and textures.");
        }
    }
}
